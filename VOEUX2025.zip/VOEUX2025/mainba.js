// phrases à afficher
const phrasesVoeux=[
    "Bonne Année 2025",
    "Meilleurs Voeux",
    "Santé, Bonheur et Travail", 
    "Que l'année 2025 exauce tous vos voeux!"
]
    
    // element HTML où afficher la phrase
    let nouvellePhrase=document.querySelector("h1")
    let i=0

    if(!nouvellePhrase) {
        console.error("pas d'element h1")
    } else {
    // fonction d'affichage de la phrase en boucle
    function afficherPhraseBoucle() {
       nouvellePhrase.textContent=phrasesVoeux[i]
    //    retour au debut du tableau
       i=(i+1)%phrasesVoeux.length

        setTimeout(afficherPhraseBoucle, 1500)

    }  
afficherPhraseBoucle()  
}
